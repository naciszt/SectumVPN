import shutil
import sys
import time
import getpass
import uuid
import requests
import nmap 
import whois
import dns.resolver

from pystyle import Colors, Colorate
from artapi import show

banner = """▄▄███▄▄·    ██╗   ██╗███████╗███╗   ██╗ ██████╗ ███╗   ███╗    ▄▄███▄▄·
██╔════╝    ██║   ██║██╔════╝████╗  ██║██╔═══██╗████╗ ████║    ██╔════╝
███████╗    ██║   ██║█████╗  ██╔██╗ ██║██║   ██║██╔████╔██║    ███████╗
╚════██║    ╚██╗ ██╔╝██╔══╝  ██║╚██╗██║██║   ██║██║╚██╔╝██║    ╚════██║
███████║     ╚████╔╝ ███████╗██║ ╚████║╚██████╔╝██║ ╚═╝ ██║    ███████║
╚═▀▀▀══╝      ╚═══╝  ╚══════╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝     ╚═╝    ╚═▀▀▀══╝"""

devby = """
────────── ✦ ──────────
  developed by whoami
────────── ✦ ──────────"""

vibor = """
╭────────────────────────────╮ ╭────────────────────────────╮ ╭────────────────────────────╮
│  [1] Пробив                │ │  [6] Email Валидатор       │ │  [11] Email Бомбер         │
│  [2] Поиск по IP           │ │  [7] Sherlock (ник)        │ │  [12] DDoS Атака           │
│  [3] Сканер портов         │ │  [8] QR-генератор          │ │  [13] IP Пингер            │
│  [4] Whois                 │ │  [9] Генератор Паролей     │ │  [14] DNS Поиск            │
│  [5] HLR Валидатор         │ │  [10] Бомбер               │ │  [15] Гугл Дорки           │
╰────────────────────────────╯ ╰────────────────────────────╯ ╰────────────────────────────╯
╭────────────────────────────╮ ╭────────────────────────────╮ ╭────────────────────────────╮
│  [16] Отправить SMS        │ │  [21] Генерация Адреса     │ │  [26] Снос почтами ТГ      │
│  [17] Отправить Э-Письмо   │ │  [22] Генерация досье HTML │ │  [27] Флуд кодами ТГ       │
│  [18] Генерация Токена     │ │  [23] Генерация сид-фразы  │ │  [28] Атака ботов ТГ       │
│  [19] Генерация ФИО        │ │  [24] Генерация Д.Р        │ │  [29] Найти ID аккаунта ТГ │
│  [20] Генерация Номера     │ │  [25] Генерация Mullvad 🗝 │ │  [30] Спам с акка ТГ       │ 
╰────────────────────────────╯ ╰────────────────────────────╯ ╰────────────────────────────╯
"""

exitmenu = "[ 0 ] Выход"

API_URL = "https://venomapi.vercel.app/api/login"

current_user = None

DEVICE_ID = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"venom:{uuid.getnode()}"))

nm = nmap.PortScanner()

def xcenter(text: str) -> str:
    width = shutil.get_terminal_size((120, 30)).columns
    return "\n".join(line.center(width) for line in text.strip("\n").splitlines())


def gradient(text: str) -> str:
    return Colorate.Vertical(Colors.white_to_black, text, 1)


def clear():
    print("\033[2J\033[H", end="")
    sys.stdout.flush()

def auth():
    global current_user

    clear()
    print(gradient(xcenter(banner)))
    print(gradient(xcenter(devby)))
    print(gradient(xcenter("\n=== Авторизация ===\n")))

    username = input(gradient("  Логин: "))
    password = getpass.getpass(gradient("  Пароль: "))

    print(gradient(xcenter("\n  Подключение...\n")))

    try:
        response = requests.post(
            API_URL,
            json={
                "username": username,
                "password": password,
                "device_id": DEVICE_ID,
            },
            timeout=10,
        )
        data = response.json()

        if not data.get("success"):
            error = data.get("error", "Неизвестная ошибка")
            print(gradient(xcenter(f"\n  [ ! ] {error}\n")))
            time.sleep(2)
            sys.exit(1)

        current_user = username
        print(gradient(xcenter(f"\n  [ ✓ ] Добро пожаловать, {current_user}!\n")))
        time.sleep(1.5)

    except requests.exceptions.ConnectionError:
        print(gradient(xcenter("\n  [ ! ] Не удалось подключиться к серверу.\n")))
        sys.exit(1)
    except requests.exceptions.Timeout:
        print(gradient(xcenter("\n  [ ! ] Сервер не отвечает.\n")))
        sys.exit(1)

def handle_choice(choice: str) -> bool:
    if choice == "1":
        clear()
        print(gradient(xcenter("\n[ WHOAMI ]\n")))
        print(gradient(xcenter("soon...\n")))

    elif choice == "2":
        clear()
        ip = input(gradient("[*] Введите IP адрес: "))
        try:
            response = requests.get(f"http://ip-api.com/json/{ip}?lang=ru", timeout=5)
            data = response.json()
            print(gradient(xcenter("\n[ Отчет по IP ]\n")))
            if data["status"] == "success":
                print(f"  IP:           {data['query']}")
                print(f"  Страна:       {data['country']}")
                print(f"  Регион:       {data['regionName']}")
                print(f"  Город:        {data['city']}")
                print(f"  Индекс:       {data['zip']}")
                print(f"  Провайдер:    {data['isp']}")
                print(f"  Организация:  {data['org']}")
                print(f"  ASN:          {data['as']}")
                print(f"  Координаты:   {data['lat']}, {data['lon']}")
                print(f"  Часовой пояс: {data['timezone']}")
            else:
                print("  Ошибка:", data.get("message", "Неизвестная ошибка"))
        except Exception as e:
            print("  Ошибка подключения:", e)

    elif choice == "3":
        clear()
        target = input(gradient("[+] Введите IP/Домен: "))
        nm.scan(target)
        for host in nm.all_hosts():
            print(gradient(xcenter(f"\n[ Сканер портов: {host}\n")))
            for proto in nm[host].all_protocols():
                print(gradient(xcenter(f"Протокол: {proto}")))
                for port in sorted(nm[host][proto].keys()):
                    state = nm[host][proto][port]["state"]
                    print(f"Порт {port}: {state}")
    elif choice == "4":
        clear()

        domain = input(gradient("[+] Введите домен: ")).strip()

        print(gradient(xcenter("\n========== WHOIS ==========\n")))

        try:
            w = whois.whois(domain)

            fields = [
            ("Domain", w.domain_name),
            ("Registrar", w.registrar),
            ("Whois Server", getattr(w, "whois_server", None)),
            ("Creation Date", w.creation_date),
            ("Updated Date", w.updated_date),
            ("Expiration Date", w.expiration_date),
            ("Status", w.status),
            ("DNSSEC", getattr(w, "dnssec", None)),
            ("Emails", w.emails),
            ("Name Servers", w.name_servers),
            ("Organization", getattr(w, "org", None)),
            ("Address", getattr(w, "address", None)),
            ("City", getattr(w, "city", None)),
            ("State", getattr(w, "state", None)),
            ("Country", getattr(w, "country", None)),
            ("Zip", getattr(w, "zipcode", None)),
            ]

            for name, value in fields:
                if value:
                    print(gradient(f"{name}: {value}"))

        except Exception as e:
            print(gradient(f"[!] Ошибка WHOIS: {e}"))

        print(gradient(xcenter("\n========== DNS ==========\n")))

        records = [
        "A",
        "AAAA",
        "MX",
        "NS",
        "TXT",
        "CNAME",
        "SOA",
        "CAA",
        ]

        for record in records:
            try:
                answers = dns.resolver.resolve(domain, record)
                print(gradient(f"\n[{record}]"))

                for answer in answers:
                    print(answer)

            except Exception:
                pass

    elif choice == "16":
        clear()
        num = input(gradient(xcenter("[+] Введите номер: ")))
        text = input(gradient(xcenter("[+] Введите текст: ")))
        sms(num, text)
    elif choice == "0":
        clear()
        print(gradient(xcenter("\n[ Выход... ]\n")))
        return False
    
    else:
        print(gradient(xcenter("\n[ ! ] Неверная опция, попробуй снова\n")))

    return True

def main():
    while True:
        clear()
        show(banner)
        print(gradient(xcenter(devby)))
        print()
        print(gradient(xcenter(vibor)))
        print(gradient(xcenter(exitmenu)))
        print()

        prompt = gradient(f"┌──({current_user}㉿venom)-[/{current_user}]")
        govno  = gradient("└─# ")

        try:
            print(prompt)
            choice = input(govno)
        except (KeyboardInterrupt, EOFError):
            clear()
            print(gradient(xcenter("\n[ Выход... ]\n")))
            break

        print()
        if not handle_choice(choice):
            break

        print()
        try:
            input(gradient(xcenter("[ Нажми Enter для продолжения ]")))
        except (KeyboardInterrupt, EOFError):
            break


if __name__ == "__main__":
    auth()
    main()
