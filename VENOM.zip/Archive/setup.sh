#!/usr/bin/env bash
set -e

echo "[*] Определение ОС..."

case "$(uname -s)" in
    Linux*) OS="linux" ;;
    Darwin*) OS="macos" ;;
    *)
        echo "[!] Эта ОС не поддерживается."
        echo "Для Windows используйте отдельный установщик."
        exit 1
        ;;
esac

echo "[+] Обнаружена: $OS"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.venom"
BIN_DIR="$HOME/.local/bin"

echo "[*] Установка в $INSTALL_DIR"

rm -rf "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
mkdir -p "$BIN_DIR"

cp -R "$SCRIPT_DIR"/. "$INSTALL_DIR"

echo "[*] Проверка Python..."

if ! command -v python3 >/dev/null 2>&1; then
    echo "[!] Python 3 не найден."
    exit 1
fi

echo "[*] Создание виртуального окружения..."

python3 -m venv "$INSTALL_DIR/venv"

echo "[*] Обновление pip..."

"$INSTALL_DIR/venv/bin/python" -m pip install --upgrade pip

if [ -f "$INSTALL_DIR/requirements.txt" ]; then
    echo "[*] Установка зависимостей..."
    "$INSTALL_DIR/venv/bin/python" -m pip install -r "$INSTALL_DIR/requirements.txt"
fi

echo "[*] Создание команды venom..."

cat > "$BIN_DIR/venom" <<EOF
#!/usr/bin/env bash
exec "$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/main.py" "\$@"
EOF

chmod +x "$BIN_DIR/venom"

PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'

for FILE in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
    touch "$FILE"
    grep -qxF "$PATH_LINE" "$FILE" || echo "$PATH_LINE" >> "$FILE"
done

sudo apt update
sudo apt install nmap

clear

echo
echo "======================================"
echo "        Venom установлен!"
echo "======================================"
echo
echo "Если команда 'venom' не найдена,"
echo "перезапустите терминал"
echo
echo "или выполните:"
echo
echo 'export PATH="$HOME/.local/bin:$PATH"'
echo
echo "После этого запускайте:"
echo
echo "venom"
echo
echo "======================================"
